# Anne — authority character references

From 13 November 2026, the four images in this folder are the authority references for Anne wherever CBTeD keeps character references: here, the private Supabase bucket, the Runway workspace and Google Drive. They replace the two multi-panel sheets registered in Supabase on 12 November 2026. Earlier CBTeD records spelled her name Ann.

These are AI-generated images of a fictional character. The repository is public by the owner's choice.

## Images

| File | View | Pixels |
|---|---|---|
| [anne-ref-01-front.png](anne-ref-01-front.png) | Front, upper body | 584 × 941 |
| [anne-ref-02-profile.png](anne-ref-02-profile.png) | Side profile, facing left | 533 × 941 |
| [anne-ref-03-full-body.png](anne-ref-03-full-body.png) | Full body, standing | 537 × 941 |
| [anne-ref-sheet.png](anne-ref-sheet.png) | All three views, exactly as supplied | 1672 × 941 |

The three single views are lossless crops of the sheet: no resizing, retouching or redrawing. Crop boxes are in [manifest.json](manifest.json).

## Identity

- Long, loose, wavy dark-blonde hair with darker roots
- Tattoos on the forearms, hand and leg; rings
- Default outfit: high-necked black lace gown with sheer lace sleeves over a black-and-burgundy brocade corset bodice, full layered skirt, black lace-up combat boots

Face, hair, tattoos and build carry the identity. The outfit is the default; a scene can change it when the lyric or script calls for it.

## Copies elsewhere

CBTeD treats this set as the authority wherever it keeps Anne's references: its private Supabase bucket `cbted-project-assets` (under `references/anne/` in the CBTeD master character project `4e3be446-0f25-47bd-800f-443afc66eb54`), the Runway workspace John and the owner's Google Drive. Older copies in those places are superseded.

[manifest.json](manifest.json) records file sizes, dimensions, SHA-256 hashes, Git blob hashes, crop boxes and CBTeD asset IDs.
