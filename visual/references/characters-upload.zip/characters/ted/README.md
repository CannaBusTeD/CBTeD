# Ted — authority character references (CannaBusTeD)

From 13 November 2026, the four images in this folder are the authority references for Ted wherever CBTeD keeps character references: here, the private Supabase bucket, the Runway workspace and Google Drive. They replace the three photographs registered on 4 November 2026, which remain in this folder's Git history.

These are AI-generated images of a fictional character. The repository is public by the owner's choice.

## Images

| File | View | Pixels |
|---|---|---|
| [ted-ref-01-front.png](ted-ref-01-front.png) | Front, upper body | 589 × 938 |
| [ted-ref-02-profile.png](ted-ref-02-profile.png) | Side profile, facing left | 550 × 938 |
| [ted-ref-03-full-body.png](ted-ref-03-full-body.png) | Full body, standing | 515 × 938 |
| [ted-ref-sheet.png](ted-ref-sheet.png) | All three views, exactly as supplied | 1672 × 941 |

The three single views are lossless crops of the sheet: no resizing, retouching or redrawing. Crop boxes are in [manifest.json](manifest.json).

## Identity

- Black textured fedora with a black band
- Squared metal-framed glasses with red-tinted lenses
- Very long grey beard tapering to a point below the chest; dark, grey-flecked curly hair at the back and sides
- Stocky build
- Default outfit: black short-sleeved shirt, black cargo trousers, black trainers, round pendant on a chain

Hat, glasses, beard, hair and build carry the identity. The outfit is the default; a scene can change it when the lyric or script calls for it. The name CannaBusTeD does not imply cannabis or drug imagery.

## Copies elsewhere

CBTeD treats this set as the authority wherever it keeps Ted's references: its private Supabase bucket `cbted-project-assets` (under `references/ted/` in the CBTeD master character project `4e3be446-0f25-47bd-800f-443afc66eb54`), the Runway workspace John and the owner's Google Drive. Older copies in those places are superseded.

[manifest.json](manifest.json) records file sizes, dimensions, SHA-256 hashes, Git blob hashes, crop boxes and CBTeD asset IDs.
